<?php

class Addition
{
    private $num1 = 0;
    private $num2 = 0;
    private $result = 0;
    
    public function __construct($num1, $num2 = null) {
        $this->num1 = $num1;
        $this->num2 = $num2 === null ? $num1 : $num2;
    }
    
    public function doAction()
    {
        $this->result = $this->num1 + $this->num2;
        return $this->result;
    }

    
}
