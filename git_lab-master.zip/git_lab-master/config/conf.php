<?php

return [
    'addition' => 'Addition',
    'subtraction' => 'Subtraction',
];